const spriteCatalog = `0radar_higher1radar_level2radar_lower3radar_police_ped4radar_wanted_radius5radar_area_blip6radar_centre7radar_north8radar_waypoint9radar_radius_blip10radar_radius_outline_blip11radar_weapon_higher12radar_weapon_lower13radar_higher_ai14radar_lower_ai15radar_police_heli_spin16radar_police_plane_move27radar_mp_crew28radar_mp_friendlies36radar_cable_car37radar_activities38radar_raceflag40radar_safehouse41radar_police42radar_police_chase43radar_police_heli44radar_bomb_a47radar_snitch48radar_planning_locations50radar_crim_carsteal51radar_crim_drugs52radar_crim_holdups54radar_crim_player56radar_cop_patrol57radar_cop_player58radar_crim_wanted59radar_heist60radar_police_station61radar_hospital62radar_assassins_mark63radar_elevator64radar_helicopter66radar_random_character67radar_security_van68radar_tow_truck70radar_illegal_parking71radar_barber72radar_car_mod_shop73radar_clothes_store75radar_tattoo76radar_armenian_family77radar_lester_family78radar_michael_family79radar_trevor_family80radar_jewelry_heist82radar_drag_race_finish84radar_rampage85radar_vinewood_tours86radar_lamar_family88radar_franklin_family89radar_chinese_strand90radar_flight_school91radar_eye_sky92radar_air_hockey93radar_bar94radar_base_jump95radar_basketball96radar_biolab_heist99radar_cabaret_club100radar_car_wash102radar_comedy_club103radar_darts104radar_docks_heist105radar_fbi_heist106radar_fbi_officers_strand107radar_finale_bank_heist108radar_financier_strand109radar_golf110radar_gun_shop111radar_internet_cafe112radar_michael_family_exile113radar_nice_house_heist114radar_random_female115radar_random_male118radar_rural_bank_heist119radar_shooting_range120radar_solomon_strand121radar_strip_club122radar_tennis123radar_trevor_family_exile124radar_michael_trevor_family126radar_triathlon127radar_off_road_racing128radar_gang_cops129radar_gang_mexicans130radar_gang_bikers133radar_snitch_red134radar_crim_cuff_keys135radar_cinema136radar_music_venue137radar_police_station_blue138radar_airport139radar_crim_saved_vehicle140radar_weed_stash141radar_hunting142radar_pool143radar_objective_blue144radar_objective_green145radar_objective_red146radar_objective_yellow147radar_arms_dealing148radar_mp_friend149radar_celebrity_theft150radar_weapon_assault_rifle151radar_weapon_bat152radar_weapon_grenade153radar_weapon_health154radar_weapon_knife155radar_weapon_molotov156radar_weapon_pistol157radar_weapon_rocket158radar_weapon_shotgun159radar_weapon_smg160radar_weapon_sniper161radar_mp_noise162radar_poi163radar_passive164radar_usingmenu171radar_gang_cops_partner173radar_weapon_minigun175radar_weapon_armour176radar_property_takeover177radar_gang_mexicans_highlight178radar_gang_bikers_highlight179radar_triathlon_cycling180radar_triathlon_swimming181radar_property_takeover_bikers182radar_property_takeover_cops183radar_property_takeover_vagos184radar_camera185radar_centre_red186radar_handcuff_keys_bikers187radar_handcuff_keys_vagos188radar_handcuffs_closed_bikers189radar_handcuffs_closed_vagos192radar_camera_badger193radar_camera_facade194radar_camera_ifruit197radar_yoga198radar_taxi205radar_shrink206radar_epsilon207radar_financier_strand_grey208radar_trevor_family_grey209radar_trevor_family_red210radar_franklin_family_grey211radar_franklin_family_blue212radar_franklin_a213radar_franklin_b214radar_franklin_c225radar_gang_vehicle226radar_gang_vehicle_bikers227radar_gang_vehicle_cops228radar_gang_vehicle_vagos229radar_guncar230radar_driving_bikers231radar_driving_cops232radar_driving_vagos233radar_gang_cops_highlight234radar_shield_bikers235radar_shield_cops236radar_shield_vagos237radar_custody_bikers238radar_custody_vagos251radar_arms_dealing_air252radar_playerstate_arrested253radar_playerstate_custody254radar_playerstate_driving255radar_playerstate_keyholder256radar_playerstate_partner262radar_ztype263radar_stinger264radar_packer265radar_monroe266radar_fairground267radar_property268radar_gang_highlight269radar_altruist270radar_ai271radar_on_mission272radar_cash_pickup273radar_chop274radar_dead275radar_territory_locked276radar_cash_lost277radar_cash_vagos278radar_cash_cops279radar_hooker280radar_friend281radar_mission_2to4282radar_mission_2to8283radar_mission_2to12284radar_mission_2to16285radar_custody_dropoff286radar_onmission_cops287radar_onmission_lost288radar_onmission_vagos289radar_crim_carsteal_cops290radar_crim_carsteal_bikers291radar_crim_carsteal_vagos292radar_band_strand293radar_simeon_family294radar_mission_1295radar_mission_2296radar_friend_darts297radar_friend_comedyclub298radar_friend_cinema299radar_friend_tennis300radar_friend_stripclub301radar_friend_livemusic302radar_friend_golf303radar_bounty_hit304radar_ugc_mission305radar_horde306radar_cratedrop307radar_plane_drop308radar_sub309radar_race310radar_deathmatch311radar_arm_wrestling312radar_mission_1to2313radar_shootingrange_gunshop314radar_race_air315radar_race_land316radar_race_sea317radar_tow318radar_garbage319radar_drill320radar_spikes321radar_firetruck322radar_minigun2323radar_bugstar324radar_submarine325radar_chinook326radar_getaway_car327radar_mission_bikers_1328radar_mission_bikers_1to2329radar_mission_bikers_2330radar_mission_bikers_2to4331radar_mission_bikers_2to8332radar_mission_bikers_2to12333radar_mission_bikers_2to16334radar_mission_cops_1335radar_mission_cops_1to2336radar_mission_cops_2337radar_mission_cops_2to4338radar_mission_cops_2to8339radar_mission_cops_2to12340radar_mission_cops_2to16341radar_mission_vagos_1342radar_mission_vagos_1to2343radar_mission_vagos_2344radar_mission_vagos_2to4345radar_mission_vagos_2to8346radar_mission_vagos_2to12347radar_mission_vagos_2to16348radar_gang_bike349radar_gas_grenade350radar_property_for_sale351radar_gang_attack_package352radar_martin_madrazzo353radar_enemy_heli_spin354radar_boost355radar_devin356radar_dock357radar_garage358radar_golf_flag359radar_hangar360radar_helipad361radar_jerry_can362radar_mask363radar_heist_prep364radar_incapacitated365radar_spawn_point_pickup366radar_boilersuit367radar_completed368radar_rockets369radar_garage_for_sale370radar_helipad_for_sale371radar_dock_for_sale372radar_hangar_for_sale373radar_placeholder_6374radar_business375radar_business_for_sale376radar_race_bike377radar_parachute378radar_team_deathmatch379radar_race_foot380radar_vehicle_deathmatch381radar_barry382radar_dom383radar_maryann384radar_cletus385radar_josh386radar_minute387radar_omega388radar_tonya389radar_paparazzo390radar_aim391radar_cratedrop_background392radar_green_and_net_player1393radar_green_and_net_player2394radar_green_and_net_player3395radar_green_and_friendly396radar_net_player1_and_net_player2397radar_net_player1_and_net_player3398radar_creator399radar_creator_direction400radar_abigail401radar_blimp402radar_repair403radar_testosterone404radar_dinghy405radar_fanatic407radar_info_icon408radar_capture_the_flag409radar_last_team_standing410radar_boat411radar_capture_the_flag_base412radar_mp_crew413radar_capture_the_flag_outline414radar_capture_the_flag_base_nobag415radar_weapon_jerrycan416radar_rp417radar_level_inside418radar_bounty_hit_inside419radar_capture_the_usaflag420radar_capture_the_usaflag_outline421radar_tank422radar_player_heli423radar_player_plane424radar_player_jet425radar_centre_stroke426radar_player_guncar427radar_player_boat428radar_mp_heist429radar_temp_1430radar_temp_2431radar_temp_3432radar_temp_4433radar_temp_5434radar_temp_6435radar_race_stunt436radar_hot_property437radar_urbanwarfare_versus438radar_king_of_the_castle439radar_player_king440radar_dead_drop441radar_penned_in442radar_beast443radar_edge_pointer444radar_edge_crosstheline445radar_mp_lamar446radar_bennys447radar_corner_number_1448radar_corner_number_2449radar_corner_number_3450radar_corner_number_4451radar_corner_number_5452radar_corner_number_6453radar_corner_number_7454radar_corner_number_8455radar_yacht456radar_finders_keepers457radar_assault_package458radar_hunt_the_boss459radar_sightseer460radar_turreted_limo461radar_belly_of_the_beast462radar_yacht_location463radar_pickup_beast464radar_pickup_zoned465radar_pickup_random466radar_pickup_slow_time467radar_pickup_swap468radar_pickup_thermal469radar_pickup_weed470radar_weapon_railgun471radar_seashark472radar_pickup_hidden473radar_warehouse474radar_warehouse_for_sale475radar_office476radar_office_for_sale477radar_truck478radar_contraband479radar_trailer480radar_vip481radar_cargobob482radar_area_outline_blip483radar_pickup_accelerator484radar_pickup_ghost485radar_pickup_detonator486radar_pickup_bomb487radar_pickup_armoured488radar_stunt489radar_weapon_lives490radar_stunt_premium491radar_adversary492radar_biker_clubhouse493radar_biker_caged_in494radar_biker_turf_war495radar_biker_joust496radar_production_weed497radar_production_crack498radar_production_fake_id499radar_production_meth500radar_production_money501radar_package502radar_capture_1503radar_capture_2504radar_capture_3505radar_capture_4506radar_capture_5507radar_capture_6508radar_capture_7509radar_capture_8510radar_capture_9511radar_capture_10512radar_quad513radar_bus514radar_drugs_package515radar_pickup_jump516radar_adversary_4517radar_adversary_8518radar_adversary_10519radar_adversary_12520radar_adversary_16521radar_laptop522radar_pickup_deadline523radar_sports_car524radar_warehouse_vehicle525radar_reg_papers526radar_police_station_dropoff527radar_junkyard528radar_ex_vech_1529radar_ex_vech_2530radar_ex_vech_3531radar_ex_vech_4532radar_ex_vech_5533radar_ex_vech_6534radar_ex_vech_7535radar_target_a536radar_target_b537radar_target_c538radar_target_d539radar_target_e540radar_target_f541radar_target_g542radar_target_h543radar_jugg544radar_pickup_repair545radar_steeringwheel546radar_trophy547radar_pickup_rocket_boost548radar_pickup_homing_rocket549radar_pickup_machinegun550radar_pickup_parachute551radar_pickup_time_5552radar_pickup_time_10553radar_pickup_time_15554radar_pickup_time_20555radar_pickup_time_30556radar_supplies557radar_property_bunker558radar_gr_wvm_1559radar_gr_wvm_2560radar_gr_wvm_3561radar_gr_wvm_4562radar_gr_wvm_5563radar_gr_wvm_6564radar_gr_covert_ops565radar_adversary_bunker566radar_gr_moc_upgrade567radar_gr_w_upgrade568radar_sm_cargo569radar_sm_hangar570radar_tf_checkpoint571radar_race_tf572radar_sm_wp1573radar_sm_wp2574radar_sm_wp3575radar_sm_wp4576radar_sm_wp5577radar_sm_wp6578radar_sm_wp7579radar_sm_wp8580radar_sm_wp9581radar_sm_wp10582radar_sm_wp11583radar_sm_wp12584radar_sm_wp13585radar_sm_wp14586radar_nhp_bag587radar_nhp_chest588radar_nhp_orbit589radar_nhp_veh1590radar_nhp_base591radar_nhp_overlay592radar_nhp_turret593radar_nhp_mg_firewall594radar_nhp_mg_node595radar_nhp_wp1596radar_nhp_wp2597radar_nhp_wp3598radar_nhp_wp4599radar_nhp_wp5600radar_nhp_wp6601radar_nhp_wp7602radar_nhp_wp8603radar_nhp_wp9604radar_nhp_cctv605radar_nhp_starterpack606radar_nhp_turret_console607radar_nhp_mg_mir_rotate608radar_nhp_mg_mir_static609radar_nhp_mg_proxy610radar_acsr_race_target611radar_acsr_race_hotring612radar_acsr_wp1613radar_acsr_wp2614radar_bat_club_property615radar_bat_cargo616radar_bat_truck617radar_bat_hack_jewel618radar_bat_hack_gold619radar_bat_keypad620radar_bat_hack_target621radar_pickup_dtb_health622radar_pickup_dtb_blast_increase623radar_pickup_dtb_blast_decrease624radar_pickup_dtb_bomb_increase625radar_pickup_dtb_bomb_decrease626radar_bat_rival_club627radar_bat_drone628radar_bat_cash_reg629radar_cctv630radar_bat_assassinate631radar_bat_pbus632radar_bat_wp1633radar_bat_wp2634radar_bat_wp3635radar_bat_wp4636radar_bat_wp5637radar_bat_wp6638radar_blimp_2639radar_oppressor_2640radar_bat_wp7641radar_arena_series642radar_arena_premium643radar_arena_workshop644radar_race_wars645radar_arena_turret646radar_arena_rc_car647radar_arena_rc_workshop648radar_arena_trap_fire649radar_arena_trap_flip650radar_arena_trap_sea651radar_arena_trap_turn652radar_arena_trap_pit653radar_arena_trap_mine654radar_arena_trap_bomb655radar_arena_trap_wall656radar_arena_trap_brd657radar_arena_trap_sbrd658radar_arena_bruiser659radar_arena_brutus660radar_arena_cerberus661radar_arena_deathbike662radar_arena_dominator663radar_arena_impaler664radar_arena_imperator665radar_arena_issi666radar_arena_sasquatch667radar_arena_scarab668radar_arena_slamvan669radar_arena_zr380670radar_ap671radar_comic_store672radar_cop_car673radar_rc_time_trials674radar_king_of_the_hill675radar_king_of_the_hill_teams676radar_rucksack677radar_shipping_container678radar_agatha679radar_casino680radar_casino_table_games681radar_casino_wheel682radar_casino_concierge683radar_casino_chips684radar_casino_horse_racing685radar_adversary_featured686radar_roulette_1687radar_roulette_2688radar_roulette_3689radar_roulette_4690radar_roulette_5691radar_roulette_6692radar_roulette_7693radar_roulette_8694radar_roulette_9695radar_roulette_10696radar_roulette_11697radar_roulette_12698radar_roulette_13699radar_roulette_14700radar_roulette_15701radar_roulette_16702radar_roulette_17703radar_roulette_18704radar_roulette_19705radar_roulette_20706radar_roulette_21707radar_roulette_22708radar_roulette_23709radar_roulette_24710radar_roulette_25711radar_roulette_26712radar_roulette_27713radar_roulette_28714radar_roulette_29715radar_roulette_30716radar_roulette_31717radar_roulette_32718radar_roulette_33719radar_roulette_34720radar_roulette_35721radar_roulette_36722radar_roulette_0723radar_roulette_00724radar_limo725radar_weapon_alien726radar_race_open_wheel727radar_rappel728radar_swap_car729radar_scuba_gear730radar_cpanel_1731radar_cpanel_2732radar_cpanel_3733radar_cpanel_4734radar_snow_truck735radar_buggy_1736radar_buggy_2737radar_zhaba738radar_gerald739radar_ron740radar_arcade741radar_drone_controls742radar_rc_tank743radar_stairs744radar_camera_2745radar_winky746radar_mini_sub747radar_kart_retro748radar_kart_modern749radar_military_quad750radar_military_truck751radar_ship_wheel752radar_ufo753radar_seasparrow2754radar_dinghy2755radar_patrol_boat756radar_retro_sports_car757radar_squadee758radar_folding_wing_jet759radar_valkyrie2760radar_sub2761radar_bolt_cutters762radar_rappel_gear763radar_keycard764radar_password765radar_island_heist_prep766radar_island_party767radar_control_tower768radar_underwater_gate769radar_power_switch770radar_compound_gate771radar_rappel_point772radar_keypad773radar_sub_controls774radar_sub_periscope775radar_sub_missile776radar_painting777radar_car_meet778radar_car_test_area779radar_auto_shop_property780radar_docks_export781radar_prize_car782radar_test_car783radar_car_robbery_board784radar_car_robbery_prep785radar_street_race_series786radar_pursuit_series787radar_car_meet_organiser788radar_securoserv789radar_bounty_collectibles790radar_movie_collectibles791radar_trailer_ramp792radar_race_organiser793radar_chalkboard_list794radar_export_vehicle795radar_train796radar_heist_diamond797radar_heist_doomsday798radar_heist_island799radar_slamvan2800radar_crusader801radar_construction_outfit802radar_overlay_jammed803radar_heist_island_unavailable804radar_heist_diamond_unavailable805radar_heist_doomsday_unavailable806radar_placeholder_7807radar_placeholder_8808radar_placeholder_9809radar_featured_series810radar_vehicle_for_sale811radar_van_keys812radar_suv_service813radar_security_contract814radar_safe815radar_ped_r816radar_ped_e817radar_payphone818radar_patriot3819radar_music_studio820radar_jubilee821radar_granger2822radar_explosive_charge823radar_deity824radar_d_champion825radar_buffalo4826radar_agency827radar_biker_bar828radar_simeon_overlay829radar_junk_skydive830radar_luxury_car_showroom831radar_car_showroom832radar_car_showroom_simeon833radar_flaming_skull834radar_weapon_ammo835radar_community_series836radar_cayo_series837radar_clubhouse_contract838radar_agent_ulp839radar_acid840radar_acid_lab841radar_dax_overlay842radar_dead_drop_package843radar_downtown_cab844radar_gun_van845radar_stash_house846radar_tractor847radar_warehouse_juggalo848radar_warehouse_juggalo_dax849radar_weapon_crowbar850radar_duffel_bag851radar_oil_tanker852radar_acid_lab_tent853radar_van_burrito854radar_acid_boost855radar_ped_gang_leader856radar_multistorey_garage857radar_seized_asset_sales858radar_cayo_attrition859radar_bicycle860radar_bicycle_trial861radar_raiju862radar_conada2863radar_overlay_ready_for_sell864radar_overlay_missing_supplies865radar_streamer216866radar_signal_jammer867radar_salvage_yard868radar_robbery_prep_equipment869radar_robbery_prep_overlay870radar_yusuf871radar_vincent872radar_vinewood_garage873radar_lstb874radar_cctv_workstation875radar_hacking_device876radar_race_drag877radar_race_drift878radar_casino_prep879radar_planning_wall880radar_weapon_crate881radar_weapon_snowball882radar_train_signals_green883radar_train_signals_red884radar_office_transporter885radar_yankton_survival886radar_daily_bounty887radar_bounty_target888radar_filming_schedule889radar_pizza_this890radar_aircraft_carrier891radar_weapon_emp892radar_maude_eccles893radar_bail_bonds_office894radar_weapon_emp_mine895radar_zombie_disease896radar_zombie_proximity897radar_zombie_fire898radar_animal_possessed899radar_mobile_phone900radar_garment_factory901radar_garment_factory_for_sale902radar_garment_factory_equipment903radar_field_hangar904radar_field_hangar_for_sale905radar_cargobob_ch53906radar_chopper_lift_ammo907radar_chopper_lift_armor908radar_chopper_lift_explosives909radar_chopper_lift_upgrade910radar_chopper_lift_weapon911radar_cargo_ship912radar_submarine_missile913radar_propeller_engine914radar_shark915radar_fast_travel916radar_plane_duster2917radar_plane_titan2918radar_collectible919radar_field_hangar_discount920radar_garment_factory_discount921radar_weapon_gusenberg_sweeper922radar_weapon_tear_gas923radar_dog924radar_bobcat_security925radar_smoke_shop926radar_smoke_shop_for_sale927radar_smoke_shop_attention928radar_helitours929radar_helitours_for_sale930radar_helitours_attention931radar_car_wash_business932radar_car_wash_business_for_sale933radar_car_wash_business_attention934radar_attention935radar_alarm936radar_helitours_discount937radar_smoke_shop_discount938radar_car_wash_business_discount939radar_real_estate940radar_medical_courier941radar_gruppe_sechs942radar_fire_station943radar_fire_truck944radar_alpha_mail945radar_ls_meteor946radar_four20_survival947radar_community_mission_series948radar_property_mansion949radar_ai_keypad950radar_taxi_self_drive951radar_train_subway952radar_trashbag953radar_mission_creator954radar_cat955radar_mansion_ai_m956radar_mansion_ai_f957radar_mansion_ai_gang`;

function parseSpriteCatalog(catalog) {
    const allowedSpriteIds = new Set([
        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16,
        27, 28, 36, 37, 38, 40, 41, 42, 43, 44, 47, 48, 50, 51, 52, 54,
        56, 57, 58, 59, 60, 61, 62, 63, 64, 66, 67, 68, 70, 71, 72, 73,
        75, 76, 77, 78, 79, 80, 82, 84, 85, 86, 88, 89, 90, 91, 92, 93,
        94, 95, 96, 99, 100, 102, 103, 104, 105, 106, 107, 108, 109, 110,
        111, 112, 113, 114, 115, 118, 119, 120, 121, 122, 123, 124, 126,
        127, 128, 129, 130, 133, 134, 135, 136, 137, 138, 139, 140, 141,
        142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154,
        155, 156, 157, 158, 159, 160, 161, 162, 163, 164
    ]);
    const entries = [...catalog.matchAll(/(\d+)(radar_[a-z0-9_]+?)(?=\d+radar_|$)/g)]
        .filter((match) => allowedSpriteIds.has(Number(match[1])))
        .map((match) => ({ id: Number(match[1]), name: match[2] }));

    const unique = new Map();
    entries.forEach((entry) => unique.set(entry.id, entry));
    return [...unique.values()].sort((a, b) => a.id - b.id);
}

// Fetch colors from Shared.lua and populate dropdown
function getColorHex(colorId) {
    const palette = {
        0: '#ffffff', 1: '#ff0000', 2: '#00ff00', 3: '#0000ff', 4: '#fffffe',
        5: '#ffff00', 6: '#ff8080', 7: '#a020f0', 8: '#ff66cc', 9: '#ffb347',
        10: '#8b5a2b', 11: '#90ee90', 12: '#87cefa', 13: '#c084fc', 14: '#4b0082',
        15: '#00ffff', 16: '#fffacd', 17: '#ff8c00', 18: '#1e90ff', 19: '#ff1493',
        20: '#b8860b', 21: '#ff7f50', 22: '#d3d3d3', 23: '#ffb6c1', 24: '#adff2f',
        25: '#228b22', 26: '#1e90ff', 27: '#8000ff', 28: '#b8860b', 29: '#00008b',
        30: '#008b8b', 31: '#a0522d', 32: '#6a5acd', 33: '#ffffe0', 34: '#ffc0cb',
        35: '#ff6b6b', 36: '#f5f5dc', 37: '#ffffff', 38: '#0000ff', 39: '#a9a9a9',
        40: '#404040', 41: '#ff4d6d', 42: '#0000ff', 43: '#79d9ff', 44: '#f6a65d',
        45: '#ffffff', 46: '#ffd700', 47: '#ff8c00', 48: '#ff4fa3', 49: '#ff0000',
        50: '#7b68ee', 51: '#fa8072', 52: '#006400', 53: '#4da3ff', 54: '#4169e1',
        55: '#c0c0c0', 56: '#8b4513', 57: '#0000ff', 58: '#4d6a8f', 59: '#ff0000',
        60: '#ffb000', 61: '#c2185b', 62: '#a9a9a9', 63: '#1f6fff', 64: '#ff7f00',
        65: '#7a5c3a', 66: '#ffb000', 67: '#0000ff', 68: '#0000ff', 69: '#00ff00',
        70: '#ffb000', 71: '#ffb000', 72: '#000000', 73: '#ffb000', 74: '#0000ff',
        75: '#ff0000', 76: '#8b0000', 77: '#0000ff', 78: '#4169e1', 79: '#ff0000',
        80: '#0000ff', 81: '#ff8c00', 82: '#98fb98', 83: '#800080', 84: '#0000ff',
        85: '#000000'
    };

    return palette[colorId] || '#7b7b7b';
}

function populateColors() {
    const colorSelect = document.getElementById('color');
    const colorPreviewGrid = document.getElementById('colorPreviewGrid');
    const colors = [
        {id: 0, name: "White"},
        {id: 1, name: "Red"},
        {id: 2, name: "Green"},
        {id: 3, name: "Blue"},
        {id: 4, name: "White (Enemy)"},
        {id: 5, name: "Yellow"},
        {id: 6, name: "Light Red"},
        {id: 7, name: "Violet"},
        {id: 8, name: "Pink"},
        {id: 9, name: "Light Orange"},
        {id: 10, name: "Light Brown"},
        {id: 11, name: "Light Green"},
        {id: 12, name: "Light Blue"},
        {id: 13, name: "Light Purple"},
        {id: 14, name: "Dark Purple"},
        {id: 15, name: "Cyan"},
        {id: 16, name: "Light Yellow"},
        {id: 17, name: "Orange"},
        {id: 18, name: "Electric Blue"},
        {id: 19, name: "Dark Pink"},
        {id: 20, name: "Dark Yellow"},
        {id: 21, name: "Dark Orange"},
        {id: 22, name: "Light Gray"},
        {id: 23, name: "Light Pink"},
        {id: 24, name: "Lemon Green"},
        {id: 25, name: "Forest Green"},
        {id: 26, name: "Electric Blue"},
        {id: 27, name: "Bright Purple"},
        {id: 28, name: "Dark Yellow"},
        {id: 29, name: "Dark Blue"},
        {id: 30, name: "Dark Cyan"},
        {id: 31, name: "Light Brown"},
        {id: 32, name: "Light Blue"},
        {id: 33, name: "Light Yellow"},
        {id: 34, name: "Light Pink"},
        {id: 35, name: "Light Red"},
        {id: 36, name: "Beige"},
        {id: 37, name: "White"},
        {id: 38, name: "Blue"},
        {id: 39, name: "Light Gray"},
        {id: 40, name: "Dark Gray"},
        {id: 41, name: "Pink Red"},
        {id: 42, name: "Blue"},
        {id: 43, name: "Light Green"},
        {id: 44, name: "Light Orange"},
        {id: 45, name: "White"},
        {id: 46, name: "Gold"},
        {id: 47, name: "Orange"},
        {id: 48, name: "Brilliant Rose"},
        {id: 49, name: "Red"},
        {id: 50, name: "Medium Purple"},
        {id: 51, name: "Salmon"},
        {id: 52, name: "Dark Green"},
        {id: 53, name: "Blizzard Blue"},
        {id: 54, name: "Oracle Blue"},
        {id: 55, name: "Silver"},
        {id: 56, name: "Brown"},
        {id: 57, name: "Blue"},
        {id: 58, name: "East Bay"},
        {id: 59, name: "Red"},
        {id: 60, name: "Yellow Orange"},
        {id: 61, name: "Mulberry Pink"},
        {id: 62, name: "Alto Gray"},
        {id: 63, name: "Jelly Bean Blue"},
        {id: 64, name: "Dark Orange"},
        {id: 65, name: "Mamba"},
        {id: 66, name: "Yellow Orange"},
        {id: 67, name: "Blue"},
        {id: 68, name: "Blue"},
        {id: 69, name: "Green"},
        {id: 70, name: "Yellow Orange"},
        {id: 71, name: "Yellow Orange"},
        {id: 72, name: "Transparent Black"},
        {id: 73, name: "Yellow Orange"},
        {id: 74, name: "Blue"},
        {id: 75, name: "Red"},
        {id: 76, name: "Deep Red"},
        {id: 77, name: "Blue"},
        {id: 78, name: "Oracle Blue"},
        {id: 79, name: "Transparent Red"},
        {id: 80, name: "Transparent Blue"},
        {id: 81, name: "Orange"},
        {id: 82, name: "Light Green"},
        {id: 83, name: "Purple"},
        {id: 84, name: "Blue"},
        {id: 85, name: "Transparent Black"}
    ];
    
    const colorButtons = [];

    const selectColor = (color, previewButton) => {
        colorSelect.value = color.id;
        document.querySelectorAll('.color-chip').forEach(node => node.classList.remove('active'));
        if (previewButton) {
            previewButton.classList.add('active');
        }
    };

    colors.forEach(color => {
        const option = document.createElement('option');
        option.value = color.id;
        option.textContent = color.name;
        colorSelect.appendChild(option);

        const previewButton = document.createElement('button');
        previewButton.type = 'button';
        previewButton.className = 'color-chip';
        previewButton.dataset.colorId = color.id;
        previewButton.innerHTML = `
            <div class="color-swatch" style="background:${getColorHex(color.id)}"></div>
            <span>${color.name}</span>
        `;
        previewButton.addEventListener('click', function() {
            selectColor(color, previewButton);
        });
        colorButtons.push(previewButton);
        colorPreviewGrid.appendChild(previewButton);
    });

    colorSelect.addEventListener('change', function() {
        const selected = colors.find(item => Number(item.id) === Number(colorSelect.value));
        if (selected) {
            const selectedButton = colorButtons.find(button => Number(button.dataset.colorId) === selected.id);
            selectColor(selected, selectedButton);
        }
    });
}

function makeFallbackSpriteIcon(sprite) {
    const name = sprite.name || '';
    const color = `hsl(${(sprite.id * 23) % 360}, 70%, 55%)`;
    let iconShape = '<circle cx="32" cy="31" r="14" fill="white" opacity="0.25" /><path d="M25 31 H39 M32 24 V38" stroke="white" stroke-width="3" stroke-linecap="round" />';

    if (name.includes('police') || name.includes('cop')) {
        iconShape = '<path d="M32 13 L47 21 V31 C47 40 40 47 32 51 C24 47 17 40 17 31 V21 Z" fill="white" opacity="0.28" /><path d="M32 19 V43 M23 31 H41" stroke="white" stroke-width="4" stroke-linecap="round" />';
    } else if (name.includes('weapon') || name.includes('gun')) {
        iconShape = '<path d="M17 25 H39 L47 30 V35 H34 L30 42 H24 V35 H17 Z" fill="white" opacity="0.32" /><path d="M20 25 V20 H29 V25" stroke="white" stroke-width="3" fill="none" />';
    } else if (name.includes('hospital') || name.includes('medical')) {
        iconShape = '<rect x="19" y="17" width="26" height="30" rx="4" fill="white" opacity="0.28" /><path d="M32 22 V42 M22 32 H42" stroke="white" stroke-width="4" stroke-linecap="round" />';
    } else if (name.includes('car') || name.includes('vehicle') || name.includes('garage')) {
        iconShape = '<path d="M17 32 L22 21 H42 L47 32 V43 H17 Z" fill="white" opacity="0.3" /><path d="M22 32 H42 M22 43 V47 M42 43 V47" stroke="white" stroke-width="3" fill="none" /><circle cx="24" cy="38" r="3" fill="white" /><circle cx="40" cy="38" r="3" fill="white" />';
    } else if (name.includes('plane') || name.includes('airport') || name.includes('flight')) {
        iconShape = '<path d="M32 14 L37 28 L50 34 L48 39 L36 36 L36 49 H29 L29 36 L16 39 L14 34 L27 28 Z" fill="white" opacity="0.32" />';
    } else if (name.includes('boat') || name.includes('dock') || name.includes('marina')) {
        iconShape = '<path d="M17 34 H47 L41 45 H23 Z" fill="white" opacity="0.3" /><path d="M32 16 V34 M23 28 H41" stroke="white" stroke-width="3" /><path d="M15 48 Q24 43 32 48 T49 48" fill="none" stroke="white" stroke-width="3" />';
    } else if (name.includes('food') || name.includes('restaurant') || name.includes('bar')) {
        iconShape = '<path d="M22 17 V29 C22 34 28 35 30 31 V17 M26 17 V31 M30 17 V31 M39 17 V47 M39 17 C47 20 47 29 39 31" stroke="white" stroke-width="3" fill="none" stroke-linecap="round" />';
    } else if (name.includes('shop') || name.includes('store') || name.includes('clothes')) {
        iconShape = '<path d="M19 25 H45 V47 H19 Z M16 25 L20 17 H44 L48 25 Z" fill="white" opacity="0.3" /><path d="M25 25 V21 M32 25 V21 M39 25 V21" stroke="white" stroke-width="3" />';
    } else if (name.includes('house') || name.includes('safehouse') || name.includes('home')) {
        iconShape = '<path d="M16 30 L32 16 L48 30 V47 H19 V30 Z" fill="white" opacity="0.3" /><path d="M29 47 V35 H36 V47" stroke="white" stroke-width="3" fill="none" />';
    } else if (name.includes('money') || name.includes('bank') || name.includes('heist') || name.includes('drug')) {
        iconShape = '<rect x="18" y="20" width="28" height="24" rx="3" fill="white" opacity="0.3" /><circle cx="32" cy="32" r="6" fill="none" stroke="white" stroke-width="3" /><path d="M24 25 H24 M40 39 H40" stroke="white" stroke-width="4" stroke-linecap="round" />';
    } else if (name.includes('race') || name.includes('golf') || name.includes('tennis') || name.includes('sport')) {
        iconShape = '<circle cx="32" cy="32" r="14" fill="none" stroke="white" stroke-width="3" /><path d="M20 25 Q32 32 44 25 M20 39 Q32 32 44 39" fill="none" stroke="white" stroke-width="2" />';
    }

    const svg = `
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">
            <defs>
                <linearGradient id="g-${sprite.id}" x1="0" x2="1" y1="0" y2="1">
                    <stop offset="0%" stop-color="#ffffff" stop-opacity="0.4"/>
                    <stop offset="100%" stop-color="${color}"/>
                </linearGradient>
            </defs>
            <rect x="2" y="2" width="60" height="60" rx="14" fill="#0f0f1a" stroke="${color}" stroke-width="2"/>
            <circle cx="32" cy="28" r="18" fill="url(#g-${sprite.id})" opacity="0.9"/>
            ${iconShape}
            <text x="32" y="56" text-anchor="middle" font-size="8" font-family="Arial" fill="#ffffff" opacity="0.85">${sprite.id}</text>
        </svg>`;

    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
}

function makeSpriteIcon(sprite) {
    return `https://docs-backend.fivem.net/blips/${sprite.name}.png`;
}

function setSpriteImage(image, sprite) {
    image.onerror = () => {
        if (image.src.endsWith('.png')) {
            image.src = `https://docs-backend.fivem.net/blips/${sprite.name}.gif`;
            return;
        }

        image.onerror = null;
        image.src = makeFallbackSpriteIcon(sprite);
    };
    image.src = makeSpriteIcon(sprite);
}

// Fetch sprites from Shared.lua and populate dropdown
function populateSprites() {
    const spriteSelect = document.getElementById('sprite');
    const spritePreviewGrid = document.getElementById('spritePreviewGrid');
    const spriteSearch = document.getElementById('spriteSearch');
    const selectedSpriteImage = document.getElementById('selectedSpriteImage');
    const selectedSpriteName = document.getElementById('selectedSpriteName');
    const selectedSpriteId = document.getElementById('selectedSpriteId');
    const sprites = parseSpriteCatalog(spriteCatalog);

    spriteSelect.innerHTML = '<option value="" disabled selected>Select sprite...</option>';
    spritePreviewGrid.innerHTML = '';

    const spriteButtons = [];

    const setSpritePreview = (sprite) => {
        if (selectedSpriteImage) {
            setSpriteImage(selectedSpriteImage, sprite);
        }
    };

    const selectSprite = (sprite, previewButton) => {
        spriteSelect.value = sprite.id;
        document.querySelectorAll('.sprite-chip').forEach(node => node.classList.remove('active'));
        if (previewButton) {
            previewButton.classList.add('active');
        }

        setSpritePreview(sprite);
        if (selectedSpriteName) {
            selectedSpriteName.textContent = sprite.name;
        }
        if (selectedSpriteId) {
            selectedSpriteId.textContent = `ID ${sprite.id}`;
        }
    };

    sprites.forEach(sprite => {
        const option = document.createElement('option');
        option.value = sprite.id;
        option.textContent = sprite.name;
        spriteSelect.appendChild(option);

        const previewButton = document.createElement('button');
        previewButton.type = 'button';
        previewButton.className = 'sprite-chip';
        previewButton.dataset.spriteId = sprite.id;
        previewButton.dataset.spriteName = sprite.name;
        previewButton.innerHTML = `
            <img class="sprite-thumb" src="${makeSpriteIcon(sprite)}" alt="${sprite.name}">
            <span>${sprite.name}</span>
        `;
        const spriteImage = previewButton.querySelector('.sprite-thumb');
        setSpriteImage(spriteImage, sprite);
        previewButton.addEventListener('click', function() {
            selectSprite(sprite, previewButton);
        });

        spriteButtons.push(previewButton);
        spritePreviewGrid.appendChild(previewButton);
    });

    spriteSelect.addEventListener('change', function() {
        const selected = sprites.find(item => Number(item.id) === Number(spriteSelect.value));
        if (selected) {
            const selectedButton = spriteButtons.find(button => Number(button.dataset.spriteId) === selected.id);
            selectSprite(selected, selectedButton);
        }
    });

    const applySpriteFilter = () => {
        const filter = (spriteSearch.value || '').toLowerCase();
        spriteButtons.forEach(button => {
            const matches = !filter || button.dataset.spriteName.toLowerCase().includes(filter);
            button.style.display = matches ? 'flex' : 'none';
        });
    };

    if (spriteSearch) {
        spriteSearch.addEventListener('input', applySpriteFilter);
    }
}

let deleteRequestPending = false;

window.addEventListener("message", function(event) {
    var v = event.data
    switch (v.action) {
        case 'hideBlip':
            deleteRequestPending = false;
            $('.contenedor').hide()
            $('.deleteblips').hide()
            $('.formblip').hide()
            $('.adminval').val('no')
        break;

        case 'showBlip':
            deleteRequestPending = false;
            $('.contenedor').fadeIn()
            $('.menu').animate({'top':'50%'})
            $('.adminval').val('no')
            $('#deleteBlipsBtn').text('Delete Blips')
        break;

        case 'deleteBlip':
     
            $('.contenedor').fadeOut()
            $('.deleteblips').fadeIn()
            $('.formblip').show()
            $('.menudelete').animate({'top':'50%'})
        break;

        case 'loadBlipsToDelete':
            let blips = v.totalblips
            $('.blipsDelete').append(`
            <option value="${blips.blipid}">${blips.name}</option>
            `
            )
        break;

        case 'noBlipsToDelete':
            $('#getBlipsSelect').empty().append('<option value="none">No blips created</option>');
            $('.BotonDelete').prop('disabled', true);
        break;

        case 'Coords':
            const cordenadas = v.coords || {}
            const coordX = Number(cordenadas.x) || 0
            const coordY = Number(cordenadas.y) || 0
            const coordZ = Number(cordenadas.z) || 0

            $('.coordx').val(coordX.toFixed(2))
            $('.coordy').val(coordY.toFixed(2))
            $('.coordz').val(coordZ.toFixed(2))
            $('#coords').val(`${coordX.toFixed(2)} ${coordY.toFixed(2)} ${coordZ.toFixed(2)}  `)
        break;

        case 'blipCreated':
            $('#coords').val('')
            $('.coordx').val('')
            $('.coordy').val('')
            $('.coordz').val('')
        break;
    }
});

$(document).keyup((e) => {
    if (e.key === "Escape") {
        setTimeout(() => {
            $.post('https://tb_blipscreator/exit', JSON.stringify({}));
        }, 300);
        let formulario = document.getElementById('formul')
        let formulario2 = document.getElementById('formblip')
        formulario.reset()
        $('#formblip')
            .find('option')
            .remove()
            .end()
            .val('Remove Blip')
        ;

    }
});

$(function () {
    // Populate color and sprite dropdowns
    populateColors();
    populateSprites();
    
    // Get coordinates button
    $('#getCoordsBtn').click(function() {
        $.post('https://tb_blipscreator/coords', JSON.stringify({}));
    });

    // Close menu button
    $('#closeMenuBtn').click(function() {
        $.post('https://tb_blipscreator/exit', JSON.stringify({}));
    });

    $('#closeDeleteBtn').click(function() {
        $.post('https://tb_blipscreator/exit', JSON.stringify({}));
    });

    // Create blip button click
    $('#createBlipBtn').click(function() {
        if($('#nombre').val() === '' || $('#sprite').val() === '' || $('#color').val() === '' || $('#coords').val() === '') {
            alert('Please fill in all fields');
            return;
        }
        
        $.post('https://tb_blipscreator/data', JSON.stringify({
            name : $('#nombre').val(),
            sprite: $('#sprite').val(),
            color : $('#color').val(),
            admin : $('.adminval').val(),
            x: $('.coordx').val(),
            y: $('.coordy').val(),
            z: $('.coordz').val(),
        }));
    });

    // Delete blips button
    $('#deleteBlipsBtn').click(function() {
        if (deleteRequestPending) {
            return;
        }
        deleteRequestPending = true;
        $('#getBlipsSelect').empty().append('<option value="none">Select Blip</option>');
        $('.BotonDelete').prop('disabled', false);
        setTimeout(() => {
            $.post('https://tb_blipscreator/delete', JSON.stringify({
                isadmin : $('.adminval').val(),
            }));
        }, 300);
    });

    // Delete blip submit
    $('.BotonDelete').click(function(e) {
        e.preventDefault();
        seleccion = $('#getBlipsSelect').find(":selected").val()
        if (!seleccion || seleccion === 'none') {
            return;
        }
        $.post('https://tb_blipscreator/DeleteBlip', JSON.stringify({
            blipid : seleccion
        }));
        $(`#getBlipsSelect option[value="${seleccion}"]`).remove();
        $('#getBlipsSelect').val('none');
    });

    // Return to the creator without closing the NUI
    $('#backToCreatorBtn').click(function() {
        deleteRequestPending = false;
        $('.deleteblips').hide();
        $('.menudelete').stop(true, true).css({'width':'', 'height':''});
        $('.contenedor').fadeIn();
        $('.menu').stop(true, true).css({'top':'50%'});
    });

});
