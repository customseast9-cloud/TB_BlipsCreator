Locales = Locales or {}

Locales.en = {
    name = 'Name',
    sprite = 'Sprite',
    color = 'Color',
    position = 'Position',
    use_current_position = 'Use current',
    create_blip = 'Create blip',
    manage_blips = 'Manage created blips',
    created_blips = 'Created blips',
    delete_blip = 'Delete blip',
    back = 'Back',
    close = 'Close',
    no_blips_created = 'No blips created',
    search_icons = 'Search icons',
    blip_created = 'Blip created successfully',
    blip_deleted = 'Blip deleted successfully',
    no_blips_to_delete = 'You have no blips to delete',
    not_authorized = 'You are not authorized to use the blip creator'
}

Lang = Locales.en
