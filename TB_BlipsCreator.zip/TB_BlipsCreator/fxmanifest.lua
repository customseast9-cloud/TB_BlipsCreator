fx_version 'cerulean'

game 'gta5'
lua54 'yes'
dependency 'ox_lib'
author 'tb scripts '
description 'TB Blip Creator'
version '1.0.0'
--Client Scripts-- 
client_scripts {
    'Client/*.lua'
}

--Server Scripts-- 
server_scripts {
    '@mysql-async/lib/MySQL.lua',
    'Server/*.lua'
}

shared_scripts {
    '@ox_lib/init.lua',
    'en.lua',
    'Shared.lua'
}
--UI Part-- 
ui_page {
    'html/index.html', 
}

--File Part-- 
files {
    'html/index.html',
    'html/app.js', 
    'html/style.css'
} 
escrow_ignore {
  'Shared.lua',
}