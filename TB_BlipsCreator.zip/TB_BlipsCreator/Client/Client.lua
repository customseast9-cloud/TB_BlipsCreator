print("^2[TB_BlipsCreator]^0 Purchased from: ^5https://tbscripts.tebex.io^0")
print("^2[TB_BlipsCreator]^0 Discord: ^5https://discord.gg/TEAFt8WwhD^0")
print("^2[TB_BlipsCreator]^7 Version 1.0.0 loaded")




local PlayerBlips = {}
local oxLib = rawget(_G, 'lib')
local Lang = (Locales and Locales.en) or {
    blip_created = 'Blip created successfully',
    no_blips_to_delete = 'You have no blips to delete'
}

local function notify(message, notificationType)
    if oxLib and oxLib.notify then
        oxLib.notify({
            description = message,
            type = notificationType or 'inform'
        })
        return
    end

    BeginTextCommandThefeedPost('STRING')
    AddTextComponentSubstringPlayerName(message)
    EndTextCommandThefeedPostTicker(false, false)
end

RegisterNetEvent('tb_blipcreator:Notify')
AddEventHandler('tb_blipcreator:Notify', function(message, notificationType)
    notify(message, notificationType)
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        if NetworkIsSessionStarted() then
            TriggerServerEvent('tb_blipcreator:GetBlips', false)
            break
        end
    end
end)


RegisterNetEvent('tb_blipcreator:OpenUI')
AddEventHandler('tb_blipcreator:OpenUI', function (admin)
    SetNuiFocus(true,true)
    SendNUIMessage({
        action = 'showBlip',
        admin = admin
    })
end)

RegisterNUICallback("exit" , function(data, cb)
    SetNuiFocus(false, false)
    SendNUIMessage({
        action = 'hideBlip'
    })
    cb('ok')
end)

RegisterNUICallback("delete" , function(data, cb)
    SendNUIMessage({
        action = 'deleteBlip'
    })
    TriggerServerEvent('tb_blipcreator:GetBlipsToDelete', data.isadmin)
    cb('ok')
end)

RegisterNetEvent('tb_blipcreator:NoBlipsToDelete')
AddEventHandler('tb_blipcreator:NoBlipsToDelete', function()
    notify(Lang.no_blips_to_delete, 'warning')
    SendNUIMessage({
        action = 'noBlipsToDelete'
    })
end)


RegisterNUICallback("DeleteBlip" , function(data, cb)
    TriggerServerEvent('tb_blipcreator:DeleteBlipPersonal', data.blipid)
    Citizen.Wait(100)
    TriggerServerEvent('tb_blipcreator:GetBlips', true)
    cb('ok')
end)

RegisterNetEvent('tb_blipcreator:BlipsABorrar')
AddEventHandler('tb_blipcreator:BlipsABorrar', function (datablip2)
    for i = 1, #datablip2 do 
        SendNUIMessage({
            action = 'loadBlipsToDelete',
            totalblips = datablip2[i]
        })
    end
end)




RegisterNUICallback("data" , function(data, cb)
    TriggerServerEvent('tb_blipcreator:SaveBlips', data.x, data.y, data.z, data.sprite, data.color, data.name, data.admin)
    local info = {}
    info = {x = data.x, y = data.y, z = data.z, sprite = data.sprite, color = data.color, name = data.name}

    if data.admin == 'yes' then 
        TriggerServerEvent('tb_blipcreator:UniversalBlipsRefresh', info)
    else
        makeBlip(info)
    end

    notify(Lang.blip_created, 'success')
    SendNUIMessage({
        action = 'blipCreated'
    })
    cb('ok')
end)

RegisterNUICallback("coords" , function(data, cb)
    local playerPed = PlayerPedId()
    local coords = GetEntityCoords(playerPed)
    SendNUIMessage({
        action = 'Coords',
        coords = {x = coords.x, y = coords.y, z = coords.z}
    })
    cb('ok')
end)


RegisterNetEvent('tb_blipcreator:MakeBlip')
AddEventHandler('tb_blipcreator:MakeBlip', function (info)
    makeBlip(info)
end)

function makeBlip(info)
    Citizen.CreateThread(function()
        info.blip = AddBlipForCoord(tonumber(info.x), tonumber(info.y), tonumber(info.z))
        SetBlipSprite(info.blip, tonumber(info.sprite))
        SetBlipDisplay(info.blip, 4)
        SetBlipScale(info.blip, 0.9)
        SetBlipColour(info.blip, tonumber(info.color))
        SetBlipAsShortRange(info.blip, true)
        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString(info.name)
        EndTextCommandSetBlipName(info.blip)
    end)
end

local oldBlips = {}
RegisterNetEvent('tb_blipcreator:LoadBlips')
AddEventHandler('tb_blipcreator:LoadBlips', function (blips, remove)
    Citizen.CreateThread(function()
        if remove == false then
            oldBlips = {}
            for _, info in pairs(blips) do
                info.blip = AddBlipForCoord(tonumber(info.x), tonumber(info.y), tonumber(info.z))
                SetBlipSprite(info.blip, tonumber(info.sprite))
                SetBlipDisplay(info.blip, 4)
                SetBlipScale(info.blip, 0.9)
                SetBlipColour(info.blip, tonumber(info.color))
                SetBlipAsShortRange(info.blip, true)
                BeginTextCommandSetBlipName("STRING")
                AddTextComponentString(info.name)
                EndTextCommandSetBlipName(info.blip)
                oldBlips[#oldBlips + 1] = info
            end
        else
            for _, info in pairs(oldBlips) do
                RemoveBlip(info.blip)
            end
        end
    end)
end)


local oldUniverseBlips = {}
RegisterNetEvent('tb_blipcreator:LoadUniversalBlips')
AddEventHandler('tb_blipcreator:LoadUniversalBlips', function (blips, remove)
    Citizen.CreateThread(function()
        if remove == false then 
            for _, info in pairs(blips) do
            info.blip = AddBlipForCoord(info.x, info.y, info.z)
            SetBlipSprite(info.blip, info.sprite)
            SetBlipDisplay(info.blip, 4)
            SetBlipScale(info.blip, 0.9)
            SetBlipColour(info.blip, info.color)
            SetBlipAsShortRange(info.blip, true)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString(info.name)
            EndTextCommandSetBlipName(info.blip)
            oldUniverseBlips = blips
            end
        end
    end)
end)

RegisterNetEvent('tb_blipcreator:ByeBye')
AddEventHandler('tb_blipcreator:ByeBye', function ()
    for _, info in pairs(oldBlips) do
        RemoveBlip(info.blip)
    end

    for _, info in pairs(oldUniverseBlips) do
        RemoveBlip(info.blip)
    end

    UpdateClientBlips()
end)

function UpdateClientBlips()
    TriggerServerEvent('tb_blipcreator:GetBlips', false)
end