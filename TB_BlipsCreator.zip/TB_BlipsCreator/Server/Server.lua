
print("^2[TB_BlipsCreator]^0 Purchased from: ^5https://tbscripts.tebex.io^0")
print("^2[TB_BlipsCreator]^0 Discord: ^5https://discord.gg/TEAFt8WwhD^0")
print("^2[TB_BlipsCreator]^7 Version 1.0.0 loaded")


local Lang = (Locales and Locales.en) or {
    blip_deleted = 'Blip deleted successfully'
}

RegisterServerEvent('tb_blipcreator:GetBlips')
AddEventHandler('tb_blipcreator:GetBlips', function (remove)
    local src = source
    RefreshBlips(src, remove)
end)

RegisterServerEvent('tb_blipcreator:SaveBlips')
AddEventHandler('tb_blipcreator:SaveBlips', function (x,y,z,sprite,color,name, isuniversal)
    local src = source
    local iden = GetIdentifier(src, Config.Identifier)
 
    if isuniversal == 'yes' then 
        Query(Config.Db, 'execute',
        "INSERT INTO tb_blips (`identifier`, `x`, `y`, `z`, `sprite`, `color`, `name`, `universal`) VALUES (@id, @x, @y, @z, @sprite, @color, @name, 1)",
        {['@id'] = 'Admin Blip', ['@x'] = x, ['@y'] = y, ['@z'] = z, ['@sprite'] = sprite, ['@color'] = color, ['@name'] = name})
    else
        Query(Config.Db, 'execute',
        "INSERT INTO tb_blips (`identifier`, `x`, `y`, `z`, `sprite`, `color`, `name`, `universal`) VALUES (@id, @x, @y, @z, @sprite, @color, @name, 0)",
        {['@id'] = iden, ['@x'] = x, ['@y'] = y, ['@z'] = z, ['@sprite'] = sprite, ['@color'] = color, ['@name'] = name})
    end
    
end)



RegisterServerEvent('tb_blipcreator:GetBlipsToDelete')
AddEventHandler('tb_blipcreator:GetBlipsToDelete', function (admin)
    local src = source
    local iden = GetIdentifier(src, Config.Identifier)
    GetBlipsToDelete(src, admin)
end)

RegisterServerEvent('tb_blipcreator:DeleteBlipPersonal')
AddEventHandler('tb_blipcreator:DeleteBlipPersonal', function (blipid)
    local src = source
    local iden = GetIdentifier(src, Config.Identifier)
    Query(Config.Db, 'execute',
        "DELETE FROM tb_blips WHERE blipid = @id AND identifier = @identifier AND universal = 0",
        {['@id'] = blipid, ['@identifier'] = iden})
    TriggerClientEvent('tb_blipcreator:Notify', src, Lang.blip_deleted, 'success')
end)

RegisterCommand('blipcreator', function(source, args, rawCommand)
    local src = source
    if CheckIsAdmin(src) then 
        TriggerClientEvent('tb_blipcreator:OpenUI', src, true)
    elseif src > 0 then
        TriggerClientEvent('tb_blipcreator:Notify', src, Lang.not_authorized, 'error')
    end
end)


RegisterServerEvent('tb_blipcreator:UniversalBlipsRefresh')
AddEventHandler('tb_blipcreator:UniversalBlipsRefresh', function (info, remove)
    TriggerClientEvent('tb_blipcreator:MakeBlip', -1, info)
end)