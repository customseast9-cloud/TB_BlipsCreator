function Query(plugin,type,query,var)
	local wait = promise.new()
    if type == 'fetchAll' and plugin == 'mysql' then
		MySQL.Async.fetchAll(query, var, function(result)
            wait:resolve(result)
        end)
    end
    if type == 'execute' and plugin == 'mysql' then
        MySQL.Async.execute(query, var, function(result)
            wait:resolve(result)
        end)
    end
    if type == 'execute' and plugin == 'ghmattisql' then
        exports['ghmattimysql']:execute(query, var, function(result)
            wait:resolve(result)
        end)
    end
    if type == 'fetchAll' and plugin == 'ghmattisql' then
        exports.ghmattimysql:execute(query, var, function(result)
            wait:resolve(result)
        end)
    end
    if type == 'execute' and plugin == 'oxmysql' then
        exports.oxmysql:execute(query, var, function(result)
            wait:resolve(result)
        end)
    end
    if type == 'fetchAll' and plugin == 'oxmysql' then
		exports['oxmysql']:fetch(query, var, function(result)
			wait:resolve(result)
		end)
    end
	return Citizen.Await(wait)
end


function GetIdentifier(src, tipo)
	local src = src 
	local license
	if tipo == 'steam' then 
		for k,v in ipairs(GetPlayerIdentifiers(src)) do
			if string.match(v, 'steam') then
				license = v
				return license
			end
		end
	elseif tipo == 'license' then 
		for k,v in ipairs(GetPlayerIdentifiers(src)) do
			if string.match(v, 'license') then
				license = v
				return license
			end
		end
	elseif tipo == 'discord' then 
		for k,v in ipairs(GetPlayerIdentifiers(src)) do
			if string.match(v, 'discord') then
				license = v
				return license
			end
		end
	end
end

function RefreshBlips(src, remover)
    local src = src
    local iden = GetIdentifier(src, Config.Identifier)
    local result = Query(Config.Db, 'fetchAll',
    "SELECT * FROM tb_blips WHERE identifier = @steam OR universal = 1",
    {['@steam'] = iden})

    if remover then 
        TriggerClientEvent('tb_blipcreator:ByeBye', -1, result, remover)
    else
        TriggerClientEvent('tb_blipcreator:LoadBlips', src, result, remover)
    end
end

function GetBlipsToDelete(src, admin)
    local src = src
    local iden = GetIdentifier(src, Config.Identifier)
    local result = Query(Config.Db, 'fetchAll',
    "SELECT * FROM tb_blips WHERE identifier = @steam",
    {['@steam'] = iden})

    TriggerClientEvent('tb_blipcreator:BlipsABorrar', src, result)

    if #result == 0 then
        TriggerClientEvent('tb_blipcreator:NoBlipsToDelete', src)
    end

 
end

function CheckIsAdmin(src)
    local iden = GetIdentifier(src, Config.Identifier)
    for k,v in pairs(Config.Admins) do 
        if v == iden then 
            return true
        end
    end
    return false
end
